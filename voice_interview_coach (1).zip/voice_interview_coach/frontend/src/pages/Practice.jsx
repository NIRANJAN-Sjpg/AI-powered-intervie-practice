import { useState, useEffect } from 'react'
import api from '../api/axios'
import AudioRecorder from '../components/AudioRecorder'
import ScoreCard from '../components/ScoreCard'

const ROLES = [
  { value: 'software', label: '💻 Software Engineer' },
  { value: 'hr',       label: '🤝 HR Round' },
  { value: 'bpo',      label: '📞 BPO / Support' },
  { value: 'data',     label: '📊 Data Analyst' },
]

const DIFFICULTIES = [
  { value: 'easy',   label: '🟢 Easy' },
  { value: 'medium', label: '🟡 Medium' },
  { value: 'hard',   label: '🔴 Hard' },
]

export default function Practice() {
  const [role, setRole]             = useState('software')
  const [difficulty, setDifficulty] = useState('easy')
  const [questions, setQuestions]   = useState([])
  const [question, setQuestion]     = useState(null)
  const [step, setStep]             = useState('setup')     // setup | record | loading | result
  const [result, setResult]         = useState(null)
  const [transcript, setTranscript] = useState('')
  const [loadingQ, setLoadingQ]     = useState(false)
  const [error, setError]           = useState('')

  const fetchQuestions = async () => {
    setLoadingQ(true)
    setError('')
    try {
      const res = await api.get(`/questions/?role=${role}&difficulty=${difficulty}`)
      setQuestions(res.data)
      if (res.data.length > 0) {
        setQuestion(res.data[0])
        setStep('record')
      } else {
        setError('No questions found for this selection. Try a different role or difficulty.')
      }
    } catch {
      setError('Failed to fetch questions. Please try again.')
    } finally {
      setLoadingQ(false)
    }
  }

  const handleTranscriptReady = async (text) => {
    setTranscript(text)
    setStep('loading')
    setError('')
    try {
      const res = await api.post('/attempts/submit/', {
        question_id: question.id,
        transcript: text,
      })
      setResult(res.data)
      setStep('result')
    } catch (err) {
      setError(err.response?.data?.error || 'Evaluation failed. Please try again.')
      setStep('record')
    }
  }

  const handleNextQuestion = () => {
    const idx = questions.indexOf(question)
    const next = questions[idx + 1] || questions[0]
    setQuestion(next)
    setResult(null)
    setTranscript('')
    setStep('record')
    setError('')
  }

  const handleRestart = () => {
    setStep('setup')
    setQuestion(null)
    setResult(null)
    setTranscript('')
    setError('')
  }

  return (
    <main className="max-w-3xl mx-auto px-4 py-8">
      <div className="mb-6">
        <h1 className="text-3xl font-black text-gray-900">🎤 Practice Interview</h1>
        <p className="text-gray-500 mt-1">Select a role, get a question, record your answer, get AI feedback.</p>
      </div>

      {/* STEP 1: Setup */}
      {step === 'setup' && (
        <div className="card space-y-6">
          <div>
            <h2 className="font-semibold text-gray-800 mb-3">Select Job Role</h2>
            <div className="grid grid-cols-2 gap-3">
              {ROLES.map(r => (
                <button
                  key={r.value}
                  onClick={() => setRole(r.value)}
                  className={`p-3 rounded-xl border-2 text-sm font-medium transition-all ${
                    role === r.value
                      ? 'border-blue-500 bg-blue-50 text-blue-700'
                      : 'border-gray-200 text-gray-600 hover:border-blue-200'
                  }`}
                >
                  {r.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <h2 className="font-semibold text-gray-800 mb-3">Select Difficulty</h2>
            <div className="flex gap-3">
              {DIFFICULTIES.map(d => (
                <button
                  key={d.value}
                  onClick={() => setDifficulty(d.value)}
                  className={`flex-1 p-3 rounded-xl border-2 text-sm font-medium transition-all ${
                    difficulty === d.value
                      ? 'border-blue-500 bg-blue-50 text-blue-700'
                      : 'border-gray-200 text-gray-600 hover:border-blue-200'
                  }`}
                >
                  {d.label}
                </button>
              ))}
            </div>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3">
              <p className="text-red-700 text-sm">{error}</p>
            </div>
          )}

          <button onClick={fetchQuestions} disabled={loadingQ} className="btn-primary w-full">
            {loadingQ ? 'Loading question...' : 'Get Question →'}
          </button>
        </div>
      )}

      {/* STEP 2: Record */}
      {step === 'record' && question && (
        <div className="space-y-5">
          {/* Question card */}
          <div className="card border-l-4 border-blue-500">
            <div className="flex items-center gap-2 mb-2">
              <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                question.difficulty === 'easy' ? 'bg-green-100 text-green-700' :
                question.difficulty === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                'bg-red-100 text-red-700'
              }`}>
                {question.difficulty.toUpperCase()}
              </span>
              <span className="text-xs text-gray-400 capitalize">{question.role.replace('_', ' ')}</span>
            </div>
            <p className="text-lg font-semibold text-gray-900">{question.text}</p>
          </div>

          {/* Tip */}
          <div className="bg-amber-50 border border-amber-100 rounded-xl p-3">
            <p className="text-amber-800 text-sm">
              💡 <strong>Tip:</strong> Speak clearly and naturally. Structure your answer with a beginning, middle, and end.
              Chrome works best for speech recognition.
            </p>
          </div>

          {/* Recorder */}
          <div className="card">
            <h3 className="font-semibold text-gray-700 mb-4">Record Your Answer</h3>
            <AudioRecorder onTranscriptReady={handleTranscriptReady} />
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3">
              <p className="text-red-700 text-sm">{error}</p>
            </div>
          )}

          <button onClick={handleRestart} className="btn-secondary w-full">
            ← Change Role / Difficulty
          </button>
        </div>
      )}

      {/* STEP 3: Loading */}
      {step === 'loading' && (
        <div className="card text-center py-16">
          <div className="animate-spin rounded-full h-14 w-14 border-b-4 border-blue-600 mx-auto mb-5" />
          <p className="text-lg font-semibold text-gray-800">Evaluating your answer...</p>
          <p className="text-gray-500 text-sm mt-1">AI is analyzing your response. This takes ~5 seconds.</p>
        </div>
      )}

      {/* STEP 4: Result */}
      {step === 'result' && result && (
        <div className="space-y-6">
          <ScoreCard
            feedback={result.feedback}
            question={result.question}
            transcript={transcript}
          />

          <div className="flex gap-3">
            <button onClick={handleNextQuestion} className="btn-primary flex-1">
              Next Question →
            </button>
            <button onClick={handleRestart} className="btn-secondary flex-1">
              Change Role
            </button>
          </div>
        </div>
      )}
    </main>
  )
}
