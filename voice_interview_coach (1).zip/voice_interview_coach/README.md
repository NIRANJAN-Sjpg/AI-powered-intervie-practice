# 🎤 AI Voice Interview Coach

A full-stack AI-powered interview practice app built with **Django + React**.

- **Speech-to-Text** — Browser Web Speech API (free, no API key needed)
- **AI Evaluation** — Google Gemini 1.5 Flash (free tier)
- **Auth** — JWT (djangorestframework-simplejwt)
- **Database** — SQLite (zero setup)

---

## ⚡ Quick Setup (5 steps)

### Step 1 — Get a FREE Gemini API Key

1. Go to: https://aistudio.google.com/app/apikey
2. Sign in with your Google account
3. Click **"Create API Key"**
4. Copy the key

---

### Step 2 — Backend Setup

Open a terminal and run:

```bash
cd backend
pip install -r requirements.txt
```

Create your `.env` file:

```bash
cp .env.example .env
```

Open `.env` and paste your Gemini key:

```
SECRET_KEY=any-random-string-you-want
DEBUG=True
GEMINI_API_KEY=paste-your-key-here
```

Run migrations and seed questions:

```bash
python manage.py migrate
python manage.py seed_questions
python manage.py runserver
```

Django is now running at: http://localhost:8000

---

### Step 3 — Frontend Setup

Open a **new terminal** and run:

```bash
cd frontend
npm install
npm run dev
```

React is now running at: http://localhost:5173

---

### Step 4 — Open the App

Go to: **http://localhost:5173**

Register an account and start practicing!

---

### Step 5 — Browser Note

Use **Google Chrome** for speech recognition.
Safari and Firefox do not support the Web Speech API.

---

## 📁 Project Structure

```
voice_interview_coach/
├── backend/
│   ├── manage.py
│   ├── requirements.txt
│   ├── .env.example
│   ├── core/           ← Django settings & URLs
│   ├── accounts/       ← Auth (register, login, JWT)
│   └── interviews/     ← Questions, Attempts, Feedback + Gemini
└── frontend/
    └── src/
        ├── pages/      ← Login, Register, Dashboard, Practice, History
        ├── components/ ← AudioRecorder, ScoreCard, Navbar
        ├── context/    ← AuthContext (JWT state)
        └── api/        ← Axios instance with auto JWT headers
```

---

## 🔌 API Endpoints

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | /api/auth/register/ | ❌ | Create account |
| POST | /api/auth/login/ | ❌ | Get JWT token |
| GET | /api/auth/me/ | ✅ | Current user |
| GET | /api/questions/ | ✅ | Questions (filter by role, difficulty) |
| POST | /api/attempts/submit/ | ✅ | Submit answer → get AI feedback |
| GET | /api/attempts/ | ✅ | All user attempts |
| GET | /api/attempts/:id/ | ✅ | Single attempt |
| GET | /api/stats/ | ✅ | User stats + progress |

---

## 🎯 How It Works

1. User selects a **job role** and **difficulty**
2. A question is fetched from the database
3. User clicks the **🎤 microphone button** to record
4. **Web Speech API** transcribes speech to text in real-time
5. User clicks **Submit for Evaluation**
6. Django sends the transcript to **Gemini 1.5 Flash**
7. Gemini returns scores (0–10) for **Clarity, Content, Confidence, Overall**
8. Result is saved and displayed as a **ScoreCard with Radar Chart**
9. User can view all past attempts in **History**

---

## 🛠️ Tech Stack

| Layer | Tech |
|-------|------|
| Frontend | React 18 + Vite + TailwindCSS |
| Charts | Recharts |
| Routing | React Router v6 |
| HTTP | Axios |
| Backend | Django 4.2 + Django REST Framework |
| Auth | JWT (simplejwt) |
| AI | Google Gemini 1.5 Flash (FREE) |
| Speech | Web Speech API (browser, FREE) |
| DB | SQLite (default) |

---

## 🔄 Switch to MySQL (optional)

In `backend/core/settings.py`, replace the DATABASES block:

```python
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'interview_db',
        'USER': 'root',
        'PASSWORD': 'your_password',
        'HOST': 'localhost',
        'PORT': '3306',
    }
}
```

Then install mysqlclient:

```bash
pip install mysqlclient
```

---

## 📝 Add More Questions

Run the admin panel:

```bash
python manage.py createsuperuser
```

Go to http://localhost:8000/admin → Questions → Add Question
